﻿param([Parameter(Mandatory=$true)][string]$ProjectRoot)
$project = (Resolve-Path -LiteralPath $ProjectRoot).Path
$blender = Join-Path $project '.march-build/blender-4.5.4-windows-x64/blender.exe'
if (!(Test-Path -LiteralPath $blender)) { $blender = (Get-Command blender -ErrorAction Stop).Source }
$cast = Join-Path $project '课堂演示/media-source/opening-film/cast/performance'
$assets = Join-Path $project '课堂演示/assets/yudu-river'
$output = Join-Path $project '.march-build/抬板A复建'
& $blender -b --factory-startup --disable-autoexec --gpu-backend vulkan -t 4 --python-exit-code 1 -P (Join-Path $PSScriptRoot 'render.py') -- --shot bridge --assets $assets --cast $cast --performer (Join-Path $cast 'performer-final.glb') --output $output --size 100 --samples 8
exit $LASTEXITCODE
