"""Retarget two CMU box-lifting performances to the workboat and door leaf."""

from math import atan2, cos, degrees, pi, radians, sin, sqrt
from pathlib import Path

import bpy
from mathutils import Matrix, Quaternion, Vector

from cmu_capture import Capture
from river_cast import axes
from river_scene import (
    BEAM_Z, BRIDGE_X, DOOR_DEPTH, DOOR_THICKNESS, DOOR_WIDTH, HERO_HULL_Y,
    STAGING_HEIGHT, clamp, ease,
)


HERE = Path(__file__).resolve().parent
VERTICAL = Vector((0, 0, 1))
FORWARD = Vector((0, -1, 0))
FINGERS = ('index', 'middle', 'ring', 'pinky')
PERFORMANCES = (
    ('115_09', 47, ((0, 182), (8, 175), (25, 154), (39, 137), (49, 132),
                     (61, 126), (69, 112), (79, 91), (85, 76))),
    ('115_07', 49, ((0, 181), (8, 175), (25, 157), (40, 139), (54, 133),
                     (63, 124), (70, 114), (80, 91), (85, 78))),
)


def time_sample(marks, frame):
    """Monotone cubic Hermite time warp through marked capture frames."""
    slopes = [(b[1] - a[1]) / (b[0] - a[0]) for a, b in zip(marks, marks[1:])]
    gradients = [slopes[0], *(2 * a * b / (a + b) for a, b in zip(slopes, slopes[1:])), slopes[-1]]
    for i, ((start, a), (end, b)) in enumerate(zip(marks, marks[1:])):
        if frame <= end:
            width = end - start
            t = (frame - start) / width
            t2, t3 = t * t, t * t * t
            return ((2 * t3 - 3 * t2 + 1) * a + (-2 * t3 + 3 * t2) * b
                    + width * ((t3 - 2 * t2 + t) * gradients[i] + (t3 - t2) * gradients[i + 1]))
    return marks[-1][1]


def retarget_frame(direction, normal):
    direction = direction.normalized()
    across = normal.cross(direction).normalized()
    return Matrix((direction, across, direction.cross(across))).transposed()


def position_rotation(actor, bone, position, rotation):
    transform = (rotation @ actor.rest[bone].to_quaternion()).to_matrix().to_4x4()
    transform.translation = position
    actor.set(bone, transform)


def articulated_chain(actor, bones, target, pole, roll_hand=None):
    first, second, end = bones
    origin = actor.inherited(first).translation
    first_rest = actor.rest_head[second] - actor.rest_head[first]
    second_rest = actor.rest_head[end] - actor.rest_head[second]
    a, b = first_rest.length, second_rest.length
    along = (target - origin).normalized()
    reach = clamp((target - origin).length, abs(a - b) + .011, a + b - .006)
    target = origin + reach * along
    across = (pole - along * along.dot(pole)).normalized()
    chord = (a * a - b * b + reach * reach) / (2 * reach)
    hinge = origin + chord * along + sqrt(max(0, a * a - chord * chord)) * across
    u, v = hinge - origin, target - hinge
    # Both humeral and radial frames share the actual hinge plane; only the radius receives pronation.
    normal = u.cross(v).normalized()
    normal_rest = first_rest.cross(second_rest).normalized()
    upper = (retarget_frame(u, normal) @ retarget_frame(first_rest, normal_rest).transposed()).to_quaternion()
    lower = (retarget_frame(v, normal) @ retarget_frame(second_rest, normal_rest).transposed()).to_quaternion()
    roll = 0
    if roll_hand is not None:
        rest_hand, hand_rotation, captured_pronation, expected_twist, holding = roll_hand
        axis = v.normalized()
        rest_width = lower @ rest_hand.col[1]
        wanted_width = hand_rotation @ rest_hand.col[1]
        a1 = (rest_width - axis * axis.dot(rest_width)).normalized()
        a2 = (wanted_width - axis * axis.dot(wanted_width)).normalized()
        twist = atan2(axis.dot(a1.cross(a2)), a1.dot(a2))
        angle = twist - expected_twist
        correction = clamp(atan2(sin(angle), cos(angle)), -.59, .59)
        # Share captured twist between radius and hand to keep the wrist from absorbing it all.
        roll = clamp(expected_twist + .47 * holding * holding * correction + .23 * captured_pronation, -1.52, 1.52)
        lower = Quaternion(axis, roll) @ lower
    position_rotation(actor, first, origin, upper)
    position_rotation(actor, second, hinge, lower)
    return target, v.normalized(), degrees(roll)


class Performance:
    def __init__(self, actor, end, definition, capture_folder=HERE):
        clip, neutral, self.marks = definition
        self.capture = Capture(capture_folder / '115.asf', capture_folder / f'{clip}.amc')
        self.actor, self.end, self.ref = actor, end, neutral
        facing = -Vector(self.capture.orientation(neutral, 'root')[:, 1])
        self.capture_to_actor = Quaternion(VERTICAL, -pi / 2 - atan2(facing.y, facing.x))
        self.yaw = (pi / 2 - .13) if end < 0 else (-pi / 2 + .10)
        self.root_anchor = Vector(self.capture.point(neutral, 'root'))
        self.flat_feet = {}
        self.hand_patches = {}
        self.skin = next(child for child in self.actor.ob.children if child.type == 'MESH'
                         and 'hand_l' in child.vertex_groups and 'MPFB' in child.name)
        self.shoes = next(child for child in self.actor.ob.children if child.name.startswith('鞋底'))
        self.outsoles = {}
        source_ankles = {side: self.point(neutral, side + 'tibia') for side in ('l', 'r')}
        center = (source_ankles['l'] + source_ankles['r']) * .5
        for side, sign in (('l', 1), ('r', -1)):
            ankle_delta = source_ankles[side] - center
            foot = self.point(neutral, side + 'foot') - source_ankles[side]
            heading = clamp(atan2(foot.x, -foot.y), -.18, .18)
            self.flat_feet[side] = (Vector((sign * .129 + ankle_delta.x * .19,
                                           .065 + clamp(ankle_delta.y, -.13, .13) * .53, 0)), heading)
            self.hand_patches[side] = self.skin_of_hand(side)
            traces = [v for v in self.shoes.data.vertices if sign * v.co.x > 0]
            lowest = min(v.co.z for v in traces)
            self.outsoles[side] = [v.index for v in traces if v.co.z < lowest + .012]

    def skin_of_hand(self, side):
        """Cache influential vertices of the actual armature mesh for board contact."""
        obj = self.skin
        names = {group.index: group.name for group in obj.vertex_groups}
        patch = []
        wrist = self.actor.rest_head[f'hand_{side}']
        hand_names = {f'hand_{side}'} | {f'{digit}_{joint:02d}_{side}'
                                       for digit in (*FINGERS, 'thumb') for joint in range(1, 4)}
        for v in obj.data.vertices:
            weights = [(names[group.group], group.weight) for group in v.groups if group.weight > .035]
            hand_weight = sum(weight for name, weight in weights if name in hand_names)
            if hand_weight > .86 and (v.co - wrist).length > .029:
                weights = [(name, weight) for name, weight in weights if name in hand_names]
                main = max(weights, key=lambda entry: entry[1])[0].removesuffix('_' + side)
                patch.append((v.index, v.co.copy(), weights, main))
        if not patch:
            raise RuntimeError(f'No weighted hand vertices on {obj.name} ({side})')
        return patch

    def point(self, frame, joint):
        whole = int(frame)
        fraction = frame - whole
        return self.capture_to_actor @ Vector(self.capture.point(whole, joint)).lerp(
            Vector(self.capture.point(whole + 1, joint)), fraction)

    def channel(self, frame, joint, index=0):
        a = self.capture.channel(int(frame), joint)[index]
        b = self.capture.channel(int(frame) + 1, joint)[index]
        return a + (b - a) * (frame % 1)

    def orientation(self, frame, joint):
        a = Matrix(self.capture.orientation(int(frame), joint)).to_quaternion()
        b = Matrix(self.capture.orientation(int(frame) + 1, joint)).to_quaternion()
        return a.slerp(b, frame % 1)

    def set_body(self, frame, capture_frame, inset, door, correction):
        actor, sign = self.actor, self.end
        distance = 1.613 if sign < 0 else 1.708
        actor.place(BRIDGE_X + sign * distance, HERO_HULL_Y + (.111 if sign < 0 else .057), STAGING_HEIGHT, self.yaw)
        translate = self.point(capture_frame, 'root') - self.capture_to_actor @ self.root_anchor
        translate = Vector((translate.x * .79, translate.y * .84,
                            translate.z * .93 - correction - (.075 if sign < 0 else .050)))
        translate += actor.turn.inverted() @ Vector((0, .056 * (1 - inset), 0))
        translate.y -= .054 * (1 - ease(frame, 55, 82))
        mapping = (('pelvis', 'root'), ('spine_01', 'lowerback'), ('spine_02', 'upperback'),
                   ('spine_03', 'thorax'), ('neck_01', 'upperneck'), ('head', 'head'),
                   ('clavicle_l', 'lclavicle'), ('clavicle_r', 'rclavicle'))
        for bone, joint in mapping:
            delta = self.orientation(capture_frame, joint) @ self.orientation(self.ref, joint).inverted()
            rotation = self.capture_to_actor @ delta @ self.capture_to_actor.inverted()
            point = actor.inherited(bone).translation
            if bone == 'pelvis':
                point += translate
            if bone == 'neck_01':
                rotation = Quaternion((1, 0, 0), .058) @ rotation
            elif bone == 'head':
                # Aim down along the leaf while keeping the outline and captured changes of gaze.
                target = actor.world_to_local(door.matrix_world @ Vector((sign * .94, -.04, .28)))
                look = target - point
                gaze = Vector((clamp(look.x / -look.y, -.28, .28), -1,
                               clamp(look.z / -look.y, -.62, -.19))) if look.y < -.03 else FORWARD
                sight = .40 + .32 * ease(frame, 3, 28) - .15 * ease(frame, 67, 86)
                rotation = rotation.slerp(FORWARD.rotation_difference(gaze.normalized()), sight)
            position_rotation(actor, bone, point, rotation)

    def foot(self, side, capture_frame, offset=0):
        actor = self.actor
        bones = tuple(f'{joint}_{side}' for joint in ('thigh', 'calf', 'foot'))
        ankle, heading = self.flat_feet[side]
        ankle = ankle.copy()
        foot_roll = Quaternion(VERTICAL, heading)
        floor_samples = [foot_roll @ point for point in actor.soles[side]]
        ankle.z = (.0016 + offset) / actor.scale - min(p.z for p in floor_samples)
        upper = self.point(capture_frame, side + 'hipjoint')
        lower = self.point(capture_frame, side + 'femur')
        toe = self.point(capture_frame, side + 'tibia')
        axis = (toe - upper).normalized()
        pole = lower - upper - axis * axis.dot(lower - upper)
        pole = pole.normalized().lerp(FORWARD, .34)
        actual, _, _ = articulated_chain(actor, bones, ankle, pole)
        position_rotation(actor, bones[-1], actual, foot_roll)
        return (actual - ankle).length * actor.scale

    def floor_clearance(self):
        bpy.context.view_layer.update()
        shoe = self.shoes.evaluated_get(bpy.context.evaluated_depsgraph_get())
        return {side: min((shoe.matrix_world @ shoe.data.vertices[index].co).z for index in indices) - STAGING_HEIGHT
                for side, indices in self.outsoles.items()}

    def finger_shapes(self, side, capture_frame, hand_rotation, grip):
        actor = self.actor
        sign = 1 if side == 'l' else -1
        rest_palm = actor.palm[side][0]
        forward = hand_rotation @ rest_palm.col[0]
        radial = hand_rotation @ rest_palm.col[1]
        palm_normal = sign * forward.cross(radial)
        curl = max(0.0, self.channel(capture_frame, side + 'fingers'))
        spread = self.channel(capture_frame, side + 'thumb', 1)
        for i, digit in enumerate(FINGERS):
            for j, fraction in enumerate((.28, .43, .29), 1):
                name = f'{digit}_{j:02d}_{side}'
                pre = actor.inherited(name)
                degree = fraction * (curl * (.69 + .13 * i) + grip * (34 - 1.2 * i))
                rotation = Quaternion(radial, radians(-sign * degree))
                transform = rotation.to_matrix().to_4x4() @ pre
                transform.translation = pre.translation
                actor.set(name, transform)
        for j, fraction in enumerate((.55, .27, .18), 1):
            name = f'thumb_{j:02d}_{side}'
            pre = actor.inherited(name)
            opposition = Quaternion(palm_normal, radians(sign * fraction * (17 * grip + .12 * abs(spread))))
            flexion = Quaternion(forward, radians(-sign * fraction * (37 * grip + .14 * abs(spread))))
            transform = (flexion @ opposition).to_matrix().to_4x4() @ pre
            transform.translation = pre.translation
            actor.set(name, transform)

    def hand_points(self, side):
        actor = self.actor
        transforms = {bone: actor.pose[bone] @ actor.inverse[bone] for bone in actor.pose if bone.endswith('_' + side)}
        for _, co, weights, region in self.hand_patches[side]:
            total = sum(weight for _, weight in weights)
            yield sum((weight * (transforms[bone] @ co) for bone, weight in weights), Vector()) / total, region

    def inspect_geometry(self, door, geometry):
        """Read the evaluated skin after the Blender armature modifier with preserve-volume enabled."""
        deformed = self.skin.evaluated_get(bpy.context.evaluated_depsgraph_get())
        to_board = door.matrix_world.inverted() @ deformed.matrix_world
        for side in ('l', 'r'):
            distances = {}
            penetration = {}
            for index, _, _, name in self.hand_patches[side]:
                point = to_board @ deformed.data.vertices[index].co
                outside = Vector((max(abs(point.x) - DOOR_WIDTH / 2, 0),
                                  max(abs(point.y) - DOOR_DEPTH / 2, 0),
                                  max(abs(point.z) - DOOR_THICKNESS / 2, 0)))
                inside = min(DOOR_WIDTH / 2 - abs(point.x), DOOR_DEPTH / 2 - abs(point.y),
                             DOOR_THICKNESS / 2 - abs(point.z))
                distance = outside.length if outside.length_squared > 0 else inside
                distances[name] = min(distances.get(name, float('inf')), distance)
                penetration[name] = max(penetration.get(name, 0), inside)
            geometry[side]['actual_board_gap_by_skin_region_m'] = distances
            geometry[side]['actual_board_intrusion_by_skin_region_m'] = penetration

    def arm(self, side, frame, capture_frame, door, lower):
        actor = self.actor
        sign = 1 if side == 'l' else -1
        short_end = self.end
        release_start = 56 if short_end < 0 else 58
        exit_board = ease(frame, release_start + (0 if side == 'l' else 2), release_start + 10)
        turn_down = ease(frame, release_start + (1 if side == 'l' else 3), release_start + 10)
        free = ease(frame, release_start + 3, release_start + 22)
        shoulder_bone, *bones = tuple(f'{joint}_{side}' for joint in ('clavicle', 'upperarm', 'lowerarm', 'hand'))
        upper, fore, hand = bones
        rest_palm, palm_length = actor.palm[side]
        camera_hand = -short_end * sign < 0
        anchor = (short_end * (DOOR_WIDTH / 2 - .015), -short_end * sign * DOOR_DEPTH * .291,
                  -DOOR_THICKNESS / 2)
        anchor_world = door.matrix_world @ Vector(anchor)
        board_to_local = actor.turn.inverted().to_matrix() @ door.matrix_world.to_3x3()
        normal = board_to_local @ VERTICAL
        direction = board_to_local @ Vector((-short_end, 0, 0))
        radial = board_to_local @ Vector((0, -short_end * sign, 0))
        # Lift with the whole forearm and let fingers arrive first under the end of the board.
        grip_forward = (direction + radial * .16 - normal * (.04 + .28 * lower)).normalized()
        grip_radial = radial - normal * (.29 - .08 * lower)

        shoulder = self.point(capture_frame, side + 'clavicle')
        elbow = self.point(capture_frame, side + 'humerus')
        wrist = self.point(capture_frame, side + 'radius')
        source_forward = (self.point(capture_frame, side + 'hand') - wrist).normalized()
        # Shape the captured relaxed palm by its measured hand-to-forearm direction and thumb vector.
        source_thumb = (self.point(capture_frame, side + 'thumb') - wrist).normalized()
        relax_forward = source_forward.lerp(Vector((sign * .12, -.08, -1)), .18).normalized()
        relax_radial = FORWARD.lerp(source_thumb, .18)
        orientation = (axes(grip_forward.lerp(relax_forward, turn_down).normalized(),
                            grip_radial.lerp(relax_radial, turn_down)) @ rest_palm.transposed()).to_quaternion()
        local_anchor = actor.world_to_local(anchor_world)
        # Clavicle leads the shoulder into the grasp by a few millimetres around its original sternum pivot.
        base = actor.inherited(upper).translation
        girdle = actor.pose[shoulder_bone]
        clavicle_dir = base - girdle.translation
        reach_dir = (local_anchor - base).normalized()
        push = .11 * lower * (1 - exit_board)
        shoulder_rot = clavicle_dir.rotation_difference(clavicle_dir.lerp(reach_dir * clavicle_dir.length, push))
        new_clavicle = shoulder_rot.to_matrix().to_4x4() @ girdle
        new_clavicle.translation = girdle.translation
        actor.set(shoulder_bone, new_clavicle)

        chain_axis = (wrist - shoulder).normalized()
        elbow_pole = elbow - shoulder - chain_axis * chain_axis.dot(elbow - shoulder)
        anatomy = Vector((sign * .32, -.03, -.95))
        pole = elbow_pole.normalized().lerp(anatomy, (.62 if short_end < 0 else .42) + .13 * lower)
        reach_source = actor.inherited(upper).translation + .90 * (wrist - shoulder)
        board_coords = door.matrix_world.inverted() @ actor.local_to_world(reach_source)
        board_coords.x = short_end * max(short_end * board_coords.x, DOOR_WIDTH / 2 + .154)
        reach_source = actor.world_to_local(door.matrix_world @ board_coords)
        # A short downward move unloads the leaf; palms clear the end before rising.
        release_wrist = local_anchor - direction * (.088 + .102 * exit_board) - normal * (.062 + .048 * exit_board)
        # The capture has a box-side grip. Adapt the palm pressure point to the lower timber face.
        position_rotation(actor, hand, release_wrist, orientation)
        self.finger_shapes(side, capture_frame, orientation, 1 - exit_board)
        offsets = [p - release_wrist for p, _ in self.hand_points(side)]
        tip_reach = .60 * palm_length
        under = [p for p in offsets if direction.dot(p) > tip_reach - .016]
        skin_top = max(normal.dot(p) for p in under)
        grip_wrist = local_anchor - direction * tip_reach - normal * (skin_top + .0007 / actor.scale)
        relief = grip_wrist - direction * (.124 * exit_board) - normal * (.035 * exit_board)
        target = relief.lerp(reach_source, free)
        pronation = self.channel(capture_frame, side + 'wrist') * pi / 180
        expected_twist = -sign * 1.12 * (1 - turn_down)
        actual, fore_axis, roll = articulated_chain(actor, bones, target, pole,
                                                   (rest_palm, orientation, pronation, expected_twist, 1 - turn_down))
        position_rotation(actor, hand, actual, orientation)
        self.finger_shapes(side, capture_frame, orientation, 1 - exit_board)
        inverse = door.matrix_world.inverted()
        local_skin = [inverse @ actor.local_to_world(point) for point, _ in self.hand_points(side)]
        approaching = [p for p in local_skin if abs(p.x) < DOOR_WIDTH / 2 + .001
                       and abs(p.y) < DOOR_DEPTH / 2 - .002]
        gap = min((abs(p.z + DOOR_THICKNESS / 2) for p in approaching), default=None)
        intrusion = max((min(p.z + DOOR_THICKNESS / 2, DOOR_THICKNESS / 2 - p.z,
                             DOOR_WIDTH / 2 - abs(p.x), DOOR_DEPTH / 2 - abs(p.y))
                         for p in approaching), default=0)
        return {'wrist_target_error_m': (actual - target).length * actor.scale,
                'wrist_flexion_deg': degrees(fore_axis.angle(orientation @ rest_palm.col[0])),
                'forearm_roll_deg': roll, 'gripping': exit_board == 0, 'near_camera_hand': camera_hand,
                'skin_to_underside_m': gap, 'skin_into_timber_m': max(0, intrusion)}

    def at(self, door, frame, lower):
        capture_frame = time_sample(self.marks, frame)
        inset = 1 - ease(frame, 4, 43)
        correction = 0
        for _ in range(3):
            self.set_body(frame, capture_frame, inset, door, correction)
            arms = {side: self.arm(side, frame, capture_frame, door, lower) for side in ('l', 'r')}
            missing = max((data['wrist_target_error_m'] for data in arms.values() if data['gripping']), default=0)
            if missing < .0005:
                break
            correction += min(.048, 1.28 * missing) * (1 - ease(frame, 53, 62))
        for side in ('l', 'r'):
            self.foot(side, capture_frame)
        floor_errors = self.floor_clearance()
        for side, gap in floor_errors.items():
            self.foot(side, capture_frame, .0013 - gap)
        soles = self.floor_clearance()
        actor = self.actor
        scene_pose = {bone: actor.local_to_world((actor.pose[bone] if bone in actor.pose else actor.inherited(bone)).translation)
                      for bone in actor.bones.keys() if bone != 'Root'}
        return {'capture': self.capture.name, 'capture_frame': capture_frame, 'floor_error_m': soles,
                'hands': arms, 'joints': {bone: list(point) for bone, point in scene_pose.items()}}


def performances(workers):
    return [Performance(actor, sign, clip) for actor, sign, clip in zip(workers, (-1, 1), PERFORMANCES)]
